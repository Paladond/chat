create function pg_catalog.lpad(text, integer) returns text
LANGUAGE SQL
AS $$
select pg_catalog.lpad($1, $2, ' ')
$$;
